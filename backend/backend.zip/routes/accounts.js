const express = require('express');
const router = express.Router();

const { authMiddleware, generateToken } = require('../middlewares/auth');

const mongoose = require('mongoose');
const { User, Account } = require('../db');

router.post('/transfer', authMiddleware, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { to, amount } = req.body;

    if (!to || !amount || amount <= 0) {
      await session.abortTransaction();
      return res.status(400).json({ message: 'Invalid transfer details' });
    }

    // 1. Find sender's account
    const senderAccount = await Account.findOne({ userId: req.userId }).session(session);
    if (!senderAccount || senderAccount.balance < amount) {
      await session.abortTransaction();
      return res.status(400).json({ message: 'Insufficient balance' });
    }

    // 2. Find receiver's userId by username
    const receiverUser = await User.findOne({ username: to });
    if (!receiverUser) {
      await session.abortTransaction();
      return res.status(404).json({ message: 'Recipient user not found' });
    }

    // 3. Find receiver's account by userId
    const receiverAccount = await Account.findOne({ userId: receiverUser._id }).session(session);
    if (!receiverAccount) {
      await session.abortTransaction();
      return res.status(404).json({ message: 'Recipient account not found' });
    }

    // 4. Transfer funds
    senderAccount.balance -= amount;
    receiverAccount.balance += amount;

    await senderAccount.save({ session });
    await receiverAccount.save({ session });

    await session.commitTransaction();
    res.status(200).json({ message: 'Transfer successful' });

  } catch (error) {
    await session.abortTransaction();
    console.error("Transfer error:", error);
    res.status(500).json({ message: 'Transfer failed', error: error.message });
  } finally {
    session.endSession();
    console.log('Transfer route completed');
  }
});

router.post("/addfunds", authMiddleware, async (req, res) => {
  const { amount } = req.body;

  if (!amount || amount <= 0) {
    return res.status(400).json({ message: "Invalid amount" });
  }

  const account = await Account.findOne({ userId: req.userId });

  if (!account) {
    return res.status(404).json({ message: "Account not found" });
  }

  account.balance += amount;
  await account.save();

  res.json({ message: "Funds added", newBalance: account.balance });
});


module.exports = router;
