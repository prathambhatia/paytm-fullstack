import { Link } from "react-router-dom";
import { AppBar } from "../components/AppBar"
import { Balance } from "../components/Balance";
import { Users } from "../components/Users";
import { useEffect } from "react";
import { useBalance } from "../hooks/useBalance";


export const Dashboard = () => {
    const firstName = localStorage.getItem("firstName") || "Pratham";

    const { balance,fetchBalance } = useBalance(null);

    useEffect(() => {
        fetchBalance();
    }, []);

    return (
        <>
            <div className="min-h-screen mx-40">
                 <AppBar text="Payments App" firstName={firstName}></AppBar>
                 <Balance balance={balance}/>
                 <Link to="/addmoney">
                    <button className="btn-green">
                        Add funds
                    </button>
                </Link>
                <Users />
             
            </div>
           
        </>
    )
}