export const Balance = ({balance}) => {
  return (
    <div className="p-4 font-semibold text-xl">
        Your Balance: ${balance}
    </div>
  )
}
