import { useEffect, useState } from "react";
import Avatar from "../components/Avatar";
import { useNavigate } from "react-router-dom";

export const Users = () => {
  const [users, setUsers] = useState([]);
  const [recentUsers, setRecentUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Simulate backend fetch for recent users
  useEffect(() => {
    setTimeout(() => {
      const dummyData = [
        { userId: "u1", firstName: "Pratham", lastName: "Bhatia" },
        { userId: "u2", firstName: "Ballu", lastName: "Singh" },
        { userId: "u3", firstName: "Alicia", lastName: "Reid" },
        { userId: "u4", firstName: "Ravi", lastName: "Verma" },
        { userId: "u5", firstName: "Sara", lastName: "Khan" },
        { userId: "u6", firstName: "Tom", lastName: "Holland" },
        { userId: "u7", firstName: "Lana", lastName: "Smith" },
        { userId: "u8", firstName: "Raj", lastName: "Kapoor" },
        { userId: "u9", firstName: "Mira", lastName: "Patel" },
        { userId: "u10", firstName: "Ali", lastName: "Ahmed" }
      ];
      setUsers(dummyData);
      setRecentUsers(dummyData);
    }, 10);
  }, []);

  // Local search filter
  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchTerm(value);

    if (value.trim() === "") {
      setUsers(recentUsers);
      return;
    }

    const filtered = recentUsers.filter((user) => {
      const fullName = `${user.firstName} ${user.lastName}`.toLowerCase();
      return fullName.includes(value.toLowerCase());
    });

    setUsers(filtered);
  };

  return (
    <>
      <div className="font-bold mt-10 mx-4 text-lg">Users:</div>
      <div className="m-4">
        <input
          type="text"
          placeholder="Search users..."
          value={searchTerm}
          onChange={handleSearch}
          className="w-full px-2 py-1 border rounded border-slate-300"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 px-4">
        {users.map((user) => (
          <User key={user._id || user.userId} user={user} />
        ))}
      </div>
    </>
  );
};

function User({ user }) {
  const navigate = useNavigate();
  return (
    <div className="flex justify-between items-center p-4 rounded-xl shadow-md bg-white">
      <div className="flex items-center space-x-3">
        <Avatar name={user.firstName} />
        <div className="text-md font-medium">
          {user.firstName} {user.lastName}
        </div>
      </div>
      <button
      onClick={() => navigate(`/send/${user.userId}`, {
            state: { firstName: user.firstName, lastName: user.lastName }
          })
            }

      className="bg-red-600 text-white px-4 py-1 rounded hover:bg-red-700 transition">
        Send
      </button>
    </div>
  );
}
