export const ButtonWarning = ({children}) => {
    return (
        <div className="font-stretch-50% text-center">
            {children}
        </div>
    )
}