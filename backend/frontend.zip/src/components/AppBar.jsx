import Avatar from "./Avatar"

export const AppBar = ({text,firstName}) => {

  return (
    <div className="flex justify-between shadow-xl p-4 rounded-xl mb-4">
        <div className="text-2xl font-bold">
            {text}
        </div>
        <div className="gap-3 flex items-center font-medium">
            
            <Avatar name={firstName} />

            {/* Welcome Text */}
            <div className="text-gray-800">
                Welcome, {firstName}!
            </div>

        </div>

    </div>

  )
}
