const Avatar = ({name}) => {
  return (

        <div className="w-9 h-9 rounded-full bg-green-600 text-white flex items-center justify-center text-lg font-semibold uppercase">
            {name.charAt(0)}
        </div>
    )
}

export default Avatar